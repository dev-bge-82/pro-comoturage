function cacherR(){
	$("#formR").css("display","none");
	$("#formP").css("display","block");
	}
function cacherP(){
	$("#formP").css("display","none");
	$("#formR").css("display","block");
	}