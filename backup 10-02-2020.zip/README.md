# comoturage
Projet Comoturage

-- v0.0.10 --
+ Mise à jour du template
+ Mise à jour du maillage de toute les pages existantes
+ Mise à jour du css de toutes les pages existantes pour corriger un BUG du footer
 (placement des icones des réseaux sociaux)


-- v0.0.9 --
+ Ajouts d'images
+ Ajouts des liens de presses avec leur images dans le fichier index.html
+ incriptionconnection.html (Statique : Fait | CSS : Fait |  )
+ profil.html (Statique : Fait | CSS : Fait |  )
+ Formatage du code

-- v0.0.8 --
+ Mise à jour du css logged.css (pour aligner texte doite du header avec photo profil)
+ Mise à jour detailsannonces.html et detailsannonces.css
+ Ajout de JQuery

-- v0.0.7 --
+ Retrait du bandeau presse dans detailsannonces.html et listeannonces.html
+ Mise du CSS detailsannonces.css et listeannonces.css par rapport au bandeau presse
+ Mise à jour de l'ancrage du bandeau presse sur toutes les pages html
+ Mise à jour du template

-- v0.0.6 --
+ Ajouts du javascript pour le fichier index.html ainsi que le formulaire dans ce même fichier
+ Correction de quelque ligne de code
+ Ajouts d'images

-- v0.0.5 --
+ detailsannonces.html (Statique : Fait | CSS : encours |  )

-- v0.0.4 --
+ logged.html (Statique : Fait | CSS : Fait |  )
+ Formatage du Code
+ Commentaire

-- v0.0.3 --
+ Template (Statique : Fait | CSS : Fait |  )
+ Images
+ listeannonces.html (Statique : Fait | CSS : Fait | js :) 
+ Formatage du Code
+ CSS + Commentaire
+ index.html (Statique : Fait | CSS : Fait |  ) 


-- v0.0.2 --
+ Ajouts 2 logo(s)
+ Ajouts des pages html manquantes

-- v0.0.1 --
+ Initial Repository