# comoturage

Projet Comoturage

-- v0.0.14 --
+ commentmarche.html (Statique : Fait | CSS : Fait |  )
+ faq.html (Statique : Fait | CSS : Fait |  )
+ appmobile.html (Statique : Fait | CSS : Pas pour le moment |  )
+ correction de quelque problème de css 
+ Ajouts du fond d'écran sur l'index
+ Ajouts de l'ancre de toutes les pages html actuel sur le logo pour retourner dans l'index.html (accueil)

-- v0.0.13 --
+ Ajouts du css pour les boutons dans les pages index.css et contact.css
+ Formatage du code de tout les fichiers .css du projet
+ mestrajets.html (Statique : Fait | CSS : Fait |  )
+ cgu_mentions.html (Statique : Fait | CSS : Fait |  )
+ cookies.html (Statique : Fait | CSS : Fait |  )
+ poli_confi.html (Statique : Fait | CSS : Fait |  )

-- v0.0.12 --
+ contact.html (Statique : Fait | CSS : Fait |  )

-- v0.0.11 --
+ Ajout d'images (réseaux sociaux)
+ Mise à jour de toutes les pages du site actuelle pour prendre on compte la charte graphique

-- v0.0.10 --
+ Ajout du backup 10-02-2020
+ Mise à jour du template
+ Mise à jour du maillage de toute les pages existantes
+ Mise à jour du css de toutes les pages existantes pour corriger un BUG du footer
 (placement des icones des réseaux sociaux)


-- v0.0.9 --
+ Ajouts d'images
+ Ajouts des liens de presses avec leur images dans le fichier index.html
+ incriptionconnection.html (Statique : Fait | CSS : Fait |  )
+ profil.html (Statique : Fait | CSS : Fait |  )
+ Formatage du code

-- v0.0.8 --
+ Mise à jour du css logged.css (pour aligner texte doite du header avec photo profil)
+ Mise à jour detailsannonces.html et detailsannonces.css
+ Ajout de JQuery

-- v0.0.7 --
+ Retrait du bandeau presse dans detailsannonces.html et listeannonces.html
+ Mise du CSS detailsannonces.css et listeannonces.css par rapport au bandeau presse
+ Mise à jour de l'ancrage du bandeau presse sur toutes les pages html
+ Mise à jour du template

-- v0.0.6 --
+ Ajouts du javascript pour le fichier index.html ainsi que le formulaire dans ce même fichier
+ Correction de quelque ligne de code
+ Ajouts d'images

-- v0.0.5 --
+ detailsannonces.html (Statique : Fait | CSS : encours |  )

-- v0.0.4 --
+ logged.html (Statique : Fait | CSS : Fait |  )
+ Formatage du Code
+ Commentaire

-- v0.0.3 --
+ Template (Statique : Fait | CSS : Fait |  )
+ Images
+ listeannonces.html (Statique : Fait | CSS : Fait | js :) 
+ Formatage du Code
+ CSS + Commentaire
+ index.html (Statique : Fait | CSS : Fait |  ) 


-- v0.0.2 --
+ Ajouts 2 logo(s)
+ Ajouts des pages html manquantes

-- v0.0.1 --
+ Initial Repository